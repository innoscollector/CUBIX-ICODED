# CAD Data — CUBIX-ICODED

## CUBIX_CAD_data.json

Full parametric geometry of the CUBIX-ICODED platform, exported from `sim/cubix_sim.py`.

### Structure

```json
{
  "project": "CUBIX-ICODED",
  "version": "v0.4.0",
  "units": "mm",
  "rotor": {
    "shape": "icosahedron",
    "edge_length_mm": 115.34,
    "bevel_angle_deg": 20.905,
    "vertices": [...],   // 12 vertices (x, y, z)
    "faces": [...]       // 20 triangular faces
  },
  "stator": {
    "shape": "dodecahedron",
    "vertices": [...],   // 20 vertices
    "phase_offset_deg": 31.71,
    "gates": [...]       // 12 gates: 3 impulse + 9 harvest
  },
  "magnets": [...],      // 60 SmCo N52, each with position + orientation vector
  "simulation_params": {...}
}
```

### Import into Fusion 360 / FreeCAD

The JSON provides vertex coordinates and face indices for direct mesh import.
For parametric CAD, use the vertices as reference points for the panel geometry.

### Regenerate

```bash
python sim/cubix_sim.py --cad-only
```
