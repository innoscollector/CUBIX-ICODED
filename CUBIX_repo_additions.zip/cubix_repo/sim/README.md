# Simulation — CUBIX-ICODED

## Files

| File | Description |
|---|---|
| `cubix_sim.py` | Main simulation engine (geometry + magnetics + dynamics + structural) |

## Usage

```bash
# All plots + CAD JSON
python sim/cubix_sim.py

# Only export CAD data (no plots)
python sim/cubix_sim.py --cad-only

# One specific plot
python sim/cubix_sim.py --plot magnetic
python sim/cubix_sim.py --plot cad
python sim/cubix_sim.py --plot dynamics
python sim/cubix_sim.py --plot structural

# Custom output folder
python sim/cubix_sim.py --out my_results
```

## Outputs

| File | What it shows |
|---|---|
| `CUBIX_CAD_3D.png` | 3D geometry, cross-section, specs table |
| `CUBIX_Magnetic_Sim.png` | Flux density heatmap, Halbach profile, gate flux linkage |
| `CUBIX_Dynamics_Sim.png` | Torque, Back-EMF, efficiency, all 12 gate waveforms |
| `CUBIX_Structural_Sim.png` | Hoop stress, safety factor, centrifugal loads |
| `CUBIX_CAD_data.json` | Full geometry in JSON (vertices, faces, magnets, gates) |

## Physics Models Used

- **Magnetic field**: 4-harmonic Halbach Fourier expansion with air-gap attenuation
- **Torque**: Faraday induction + RL impedance per coil winding
- **Efficiency**: Net mechanical power / electromagnetic input power
- **Structural**: Rotating disk hoop stress (Lamé equations), centrifugal force on SmCo magnets
